# Pemjung Guardian — Android App

Your good side, watching your phone. Warns you (with vibration) when Instagram,
Facebook, or an adult site is in front, and locks that app/site for 10 minutes
if you don't leave in time.

## How it works
- **GuardianAccessibilityService** watches which app is in the foreground.
  - If it's Instagram/Facebook → triggers the warning.
  - If it's a supported browser (Chrome, Firefox, Brave, Edge), it reads the
    address bar text and checks it against an adult-site keyword list.
- **OverlayManager** draws a full-screen warning ("I'm you, Pemjung...") with
  a countdown, and vibrates the phone.
- If you don't leave within the grace period (default 8s), it locks that
  app/site for 10 minutes — a persistent lock screen reappears every time you
  reopen it during the lock window.
- Settings (your name, blocked apps, keywords, timings) live in `Prefs.kt`
  and are stored in SharedPreferences. `MainActivity` currently exposes just
  the name field + permission shortcuts; edit `Prefs.DEFAULT_APPS` /
  `Prefs.DEFAULT_KEYWORDS` directly to change the block list, or extend
  `MainActivity`/`activity_main.xml` with more fields if you want it in-app.

## Build & install — Option A: no Android Studio, build in the cloud (recommended if you don't want to install Android Studio)
This project includes a GitHub Actions workflow (`.github/workflows/build.yml`)
that compiles the APK on GitHub's servers for free.

1. Create a free GitHub account at github.com if you don't have one.
2. Create a new repository (Public or Private — either works).
3. Upload this whole `pemjung-guardian-android` folder into that repo:
   easiest way is dragging the folder onto the "Add file → Upload files" page
   in your browser (Chrome/Edge preserve folder structure on drag), or use
   `git push` if you're comfortable with git.
4. Go to the **Actions** tab of your repo. The workflow should start
   automatically after the upload (or click **Run workflow** if it doesn't).
5. Wait ~2–4 minutes for it to finish (green checkmark).
6. Click into the finished run → scroll to **Artifacts** → download
   `pemjung-guardian-debug-apk` (it's a zip containing `app-debug.apk`).
7. Transfer `app-debug.apk` to your phone (email it to yourself, upload to
   Google Drive, or plug in via USB and copy it over).
8. On your phone, tap the APK file to install. Android will warn you it's
   from an "unknown source" — that's expected for a personal project not on
   the Play Store; tap **Settings → allow this source**, then install.
9. Continue with "After installing, on the phone" below.

## Build & install — Option B: Android Studio on your own computer
You'll need **Android Studio** (free, from developer.android.com).
1. Open this folder (`pemjung-guardian-android`) as a project in Android Studio.
2. Let Gradle sync (it will download dependencies the first time).
3. Connect your Android phone via USB with **USB debugging** enabled
   (Settings → About phone → tap "Build number" 7x → Developer options →
   USB debugging), or use an emulator.
4. Click **Run ▶** to install it on your device.

## After installing, on the phone
1. Open **Pemjung Guardian**, type your name, tap **Save name**.
2. Tap **Open overlay permission settings** → allow "Display over other apps"
   for Pemjung Guardian.
3. Tap **Open Accessibility settings** → find **Pemjung Guardian** → turn the
   toggle **on** → confirm.
4. Done. Open Instagram or Facebook to test — you should feel a vibration and
   see the warning within a second.

## Important limitations (be aware of these)
- **Android only.** iOS does not allow third-party apps to monitor or overlay
  other apps this way — Apple's sandboxing blocks it. If you want this on
  iPhone, the realistic path is Apple's built-in **Screen Time** (Settings →
  Screen Time → App Limits, or the **Shortcuts** app with Screen Time
  automations) — it can block/limit apps and browsing categories, though it
  can't show your own custom message + vibration exactly like this can.
- The address-bar reading only works for the browsers listed in
  `Prefs.BROWSER_URL_BAR_IDS`, and browser UI changes over time can break the
  resource-id it looks for — treat the adult-site detection as best-effort,
  not airtight.
- Accessibility Services are powerful — that's exactly why Android requires
  an explicit, deliberate toggle to enable one. Nothing here is hidden: you
  can see and read all the code, and you can turn it off anytime from
  Accessibility settings.
- This isn't designed to be a device the user can't defeat (e.g. Accessibility
  can always be turned back off manually) — it's a friction + nudge tool for
  your own self-control, not a tamper-proof lock.
