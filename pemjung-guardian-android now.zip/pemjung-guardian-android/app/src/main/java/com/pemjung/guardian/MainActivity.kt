package com.pemjung.guardian

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val nameInput = findViewById<EditText>(R.id.nameInput)
        nameInput.setText(Prefs.getName(this))

        findViewById<Button>(R.id.saveNameButton).setOnClickListener {
            val name = nameInput.text.toString().trim().ifBlank { "Pemjung" }
            Prefs.setName(this, name)
            Toast.makeText(this, "Saved. Warnings will say \"I'm you, $name\".", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.overlayPermButton).setOnClickListener {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }

        findViewById<Button>(R.id.accessibilityButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
    }
}
