package com.pemjung.guardian

import android.content.Context

object Prefs {
    private const val FILE = "pemjung_guardian_prefs"

    private const val KEY_NAME = "name"
    private const val KEY_APPS = "blocked_packages"
    private const val KEY_KEYWORDS = "adult_keywords"
    private const val KEY_GRACE = "grace_seconds"
    private const val KEY_LOCK_MIN = "lock_minutes"
    private const val KEY_LOCK_UNTIL = "lock_until_"

    val DEFAULT_APPS = setOf(
        "com.instagram.android",
        "com.facebook.katana",
        "com.facebook.lite"
    )

    val DEFAULT_KEYWORDS = setOf(
        "porn", "pornhub", "xvideos", "xnxx", "xxx", "hentai",
        "onlyfans", "redtube", "youporn", "brazzers", "youjizz", "sex.com"
    )

    // Known browser packages + the resource-id suffix where their address bar text lives
    val BROWSER_URL_BAR_IDS = mapOf(
        "com.android.chrome" to "url_bar",
        "com.chrome.beta" to "url_bar",
        "com.brave.browser" to "url_bar",
        "org.mozilla.firefox" to "url_bar_title",
        "com.microsoft.emmx" to "url_bar" // Edge
    )

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun getName(ctx: Context): String = prefs(ctx).getString(KEY_NAME, "Pemjung") ?: "Pemjung"
    fun setName(ctx: Context, name: String) = prefs(ctx).edit().putString(KEY_NAME, name).apply()

    fun getBlockedApps(ctx: Context): Set<String> =
        prefs(ctx).getStringSet(KEY_APPS, DEFAULT_APPS) ?: DEFAULT_APPS

    fun setBlockedApps(ctx: Context, apps: Set<String>) =
        prefs(ctx).edit().putStringSet(KEY_APPS, apps).apply()

    fun getKeywords(ctx: Context): Set<String> =
        prefs(ctx).getStringSet(KEY_KEYWORDS, DEFAULT_KEYWORDS) ?: DEFAULT_KEYWORDS

    fun setKeywords(ctx: Context, kws: Set<String>) =
        prefs(ctx).edit().putStringSet(KEY_KEYWORDS, kws).apply()

    fun getGraceSeconds(ctx: Context): Int = prefs(ctx).getInt(KEY_GRACE, 8)
    fun setGraceSeconds(ctx: Context, v: Int) = prefs(ctx).edit().putInt(KEY_GRACE, v).apply()

    fun getLockMinutes(ctx: Context): Int = prefs(ctx).getInt(KEY_LOCK_MIN, 10)
    fun setLockMinutes(ctx: Context, v: Int) = prefs(ctx).edit().putInt(KEY_LOCK_MIN, v).apply()

    // lock state is keyed per target (package name or "browser:<keyword>")
    fun getLockUntil(ctx: Context, targetKey: String): Long =
        prefs(ctx).getLong(KEY_LOCK_UNTIL + targetKey, 0L)

    fun setLockUntil(ctx: Context, targetKey: String, untilMillis: Long) =
        prefs(ctx).edit().putLong(KEY_LOCK_UNTIL + targetKey, untilMillis).apply()
}
