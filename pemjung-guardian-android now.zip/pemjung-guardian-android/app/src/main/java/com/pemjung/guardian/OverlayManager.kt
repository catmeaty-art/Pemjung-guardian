package com.pemjung.guardian

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Draws a full-screen system overlay used both for the initial warning
 * (with countdown) and for the 10-minute lock screen.
 */
class OverlayManager(private val context: Context) {

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var rootView: LinearLayout? = null
    private val handler = Handler(Looper.getMainLooper())

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    fun isShowing(): Boolean = rootView != null

    fun vibrate() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator.vibrate(
                    VibrationEffect.createWaveform(longArrayOf(0, 250, 100, 250, 100, 400), -1)
                )
            } else {
                @Suppress("DEPRECATION")
                val v = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 250, 100, 250, 100, 400), -1))
                } else {
                    @Suppress("DEPRECATION")
                    v.vibrate(longArrayOf(0, 250, 100, 250, 100, 400), -1)
                }
            }
        } catch (_: Exception) { /* ignore devices without vibrator */ }
    }

    private fun buildContainer(): LinearLayout {
        val container = LinearLayout(context)
        container.orientation = LinearLayout.VERTICAL
        container.gravity = Gravity.CENTER
        container.setBackgroundColor(Color.parseColor("#F00A0A0F"))
        container.setPadding(64, 64, 64, 64)
        return container
    }

    private fun textView(text: String, sizeSp: Float, bold: Boolean, color: Int): TextView {
        val tv = TextView(context)
        tv.text = text
        tv.textSize = sizeSp
        tv.setTextColor(color)
        tv.gravity = Gravity.CENTER
        if (bold) tv.setTypeface(tv.typeface, Typeface.BOLD)
        return tv
    }

    fun showWarning(name: String, secondsLeftProvider: () -> Int) {
        removeInternal()
        val container = buildContainer()
        container.addView(
            textView(
                "I'm you, $name. I'm your good side.\nWhat are you doing?! Do you want to strengthen your loser side?\nYou will regret doing this.",
                20f, true, Color.WHITE
            )
        )
        val countdown = textView("", 15f, false, Color.parseColor("#FFB0B0"))
        container.addView(countdown)
        rootView = container
        addToWindow(container)
        vibrate()

        val ticker = object : Runnable {
            override fun run() {
                val s = secondsLeftProvider()
                countdown.text = "Get out now. Locking in ${s}s."
                if (s > 0 && rootView != null) handler.postDelayed(this, 1000)
            }
        }
        handler.post(ticker)
    }

    fun showLocked(name: String, msLeftProvider: () -> Long) {
        removeInternal()
        val container = buildContainer()
        container.addView(
            textView("I'm you, $name. Locked out — you already got the warning.", 20f, true, Color.WHITE)
        )
        val countdown = textView("", 30f, true, Color.parseColor("#FF6B6B"))
        container.addView(countdown)
        container.addView(
            textView("This is locked for a while. Go do something better.", 14f, false, Color.parseColor("#CCCCCC"))
        )
        rootView = container
        addToWindow(container)

        val ticker = object : Runnable {
            override fun run() {
                val ms = msLeftProvider()
                if (ms <= 0) {
                    remove()
                    return
                }
                val mm = (ms / 60000).toString().padStart(2, '0')
                val ss = ((ms % 60000) / 1000).toString().padStart(2, '0')
                countdown.text = "$mm:$ss"
                if (rootView != null) handler.postDelayed(this, 1000)
            }
        }
        handler.post(ticker)
    }

    private fun addToWindow(view: LinearLayout) {
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            0, // fully touchable & focusable: intercepts taps so the app underneath can't be used
            android.graphics.PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.CENTER
        try {
            windowManager.addView(view, params)
        } catch (_: Exception) {
            // Overlay permission not granted yet — silently no-op; MainActivity guides the user to grant it.
        }
    }

    private fun removeInternal() {
        rootView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        rootView = null
        handler.removeCallbacksAndMessages(null)
    }

    fun remove() = removeInternal()
}
