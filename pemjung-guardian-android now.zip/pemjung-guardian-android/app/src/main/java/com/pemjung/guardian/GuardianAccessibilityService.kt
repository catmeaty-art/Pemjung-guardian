package com.pemjung.guardian

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlin.math.max

/**
 * Watches which app/page is in front. If it's a blocked app (Instagram, Facebook, ...)
 * or a browser showing an adult-site keyword in the address bar, it shows a warning
 * overlay with vibration. If the user doesn't leave within the grace period, it locks
 * that target for N minutes.
 */
class GuardianAccessibilityService : AccessibilityService() {

    private lateinit var overlay: OverlayManager
    private val handler = Handler(Looper.getMainLooper())

    private var currentTarget: String? = null
    private var pendingLockRunnable: Runnable? = null
    private var warningStartedAt: Long = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        overlay = OverlayManager(applicationContext)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == applicationContext.packageName) return // ignore our own UI

        val blockedApps = Prefs.getBlockedApps(applicationContext)
        val browserIds = Prefs.BROWSER_URL_BAR_IDS

        when {
            blockedApps.contains(pkg) -> {
                trigger(pkg)
            }
            browserIds.containsKey(pkg) -> {
                val idSuffix = browserIds.getValue(pkg)
                val urlText = findUrlBarText(rootInActiveWindow, idSuffix)?.lowercase()
                val keywords = Prefs.getKeywords(applicationContext)
                val matched = urlText?.let { text -> keywords.firstOrNull { text.contains(it) } }
                if (matched != null) {
                    trigger("browser:$matched")
                } else {
                    clearIfNoLongerTarget(null)
                }
            }
            else -> {
                clearIfNoLongerTarget(null)
            }
        }
    }

    private fun findUrlBarText(node: AccessibilityNodeInfo?, idSuffix: String, depth: Int = 0): String? {
        if (node == null || depth > 40) return null
        val resId = node.viewIdResourceName
        if (resId != null && resId.endsWith(idSuffix)) {
            val text = node.text?.toString()
            if (!text.isNullOrBlank()) return text
        }
        for (i in 0 until node.childCount) {
            val result = findUrlBarText(node.getChild(i), idSuffix, depth + 1)
            if (result != null) return result
        }
        return null
    }

    private fun trigger(targetKey: String) {
        val name = Prefs.getName(applicationContext)
        val now = System.currentTimeMillis()
        val lockUntil = Prefs.getLockUntil(applicationContext, targetKey)

        if (lockUntil > now) {
            currentTarget = targetKey
            cancelPendingLock()
            overlay.showLocked(name) { Prefs.getLockUntil(applicationContext, targetKey) - System.currentTimeMillis() }
            return
        }

        if (currentTarget == targetKey && overlay.isShowing()) return // already warning this exact target

        currentTarget = targetKey
        cancelPendingLock()
        warningStartedAt = now
        val graceSeconds = Prefs.getGraceSeconds(applicationContext)

        overlay.showWarning(name) {
            max(graceSeconds - ((System.currentTimeMillis() - warningStartedAt) / 1000).toInt(), 0)
        }

        val runnable = Runnable {
            if (currentTarget == targetKey) {
                val lockMinutes = Prefs.getLockMinutes(applicationContext)
                val until = System.currentTimeMillis() + lockMinutes * 60_000L
                Prefs.setLockUntil(applicationContext, targetKey, until)
                overlay.showLocked(name) { Prefs.getLockUntil(applicationContext, targetKey) - System.currentTimeMillis() }
            }
        }
        pendingLockRunnable = runnable
        handler.postDelayed(runnable, graceSeconds * 1000L)
    }

    private fun clearIfNoLongerTarget(newTarget: String?) {
        if (currentTarget == newTarget) return
        currentTarget = newTarget
        cancelPendingLock()
        overlay.remove()
    }

    private fun cancelPendingLock() {
        pendingLockRunnable?.let { handler.removeCallbacks(it) }
        pendingLockRunnable = null
    }

    override fun onInterrupt() {
        overlay.remove()
    }
}
